// Dev-only: lets the UI run in a normal browser (vite dev server) with sample data, so the look can
// be checked without the Tauri backend. main.tsx imports this only when Tauri isn't present.
const sampleInstances = [
  { id: "cinematic", name: "Cinematic 1.21.11", icon: "film", group: "", mcVersion: "1.21.11", loader: "fabric", loaderVersion: "", installedId: "", ramMb: null, javaPath: "", jvmArgs: "", width: null, height: null, created: 1790000000, lastPlayed: Date.now() / 1000 - 3600, playtimeSecs: 18200, template: "cinematic", modProfile: "", modProfiles: {}, recordingMode: true, lightMode: false },
  { id: "pvp18", name: "1.8.9 PvP", icon: "gamepad", group: "", mcVersion: "1.8.9", loader: "forge", loaderVersion: "", installedId: "", ramMb: null, javaPath: "", jvmArgs: "", width: null, height: null, created: 1790000000, lastPlayed: Date.now() / 1000 - 86400, playtimeSecs: 5400, template: "pvp18", modProfile: "", modProfiles: {}, recordingMode: false, lightMode: false },
];
const settings = {
  dataDir: "D:\\JusticeClient", ramMb: 6144, jvmArgs: "", onLaunch: "hide", language: new URLSearchParams(location.search).get("lang") ?? "cs", curseforgeKey: "", msClientId: "", discordRpc: true,
  discordAppId: "", streamerMode: false, backupOnExit: false, width: 1280, height: 720, highPriority: true, gc: "auto", obsEnabled: false,
  obsUrl: "ws://127.0.0.1:4455", obsPassword: "", obsAutoRecord: false, obsScene: "", onboarded: true, accentColor: "#e11d38", bgStyle: "void", quickServers: {}, justiceMod: true, ui: { shortcuts: [{ kind: "instance", id: "cinematic" }], startPage: new URLSearchParams(location.search).get("page") ?? "home" },
};

const clipsSettings = {
  clipsDir: "D:\Justice Clips", hotkey: "F8", bufferSecs: 60, postSecs: 1, fps: 60, quality: "balanced", monitor: 0, drawMouse: true, gameAudio: true,
  gameDevice: "", mic: true, micDevice: "", micVolume: 1, audioOffsetMs: 0, overlay: true, sound: true, gameFolders: true, ffmpegPath: "", enabled: true,
};
const sampleClips = [
  ["Triple kill na Justice SMP", "PvP 1.21.11", null, 38, 58e6, 600],
  ["Clutch s perlou", "PvP 1.21.11", null, 60, 91e6, 7200],
  ["Base tour", "Cinematic 1.21.11", null, 45, 70e6, 90000],
  ["Bedwars final", "1.8.9 PvP", null, 22, 31e6, 300000],
].map(([name, game, thumb, duration, size, ago]) => ({ path: `D:\Justice Clips\${name}.mp4`, name, game, thumb, duration, size, modified: Date.now() - (ago as number) * 1000, audioTracks: 3 }));

// ?shots=1 uses real screenshots from /devmock (only present while taking website screenshots).
const SHOTS = new URLSearchParams(location.search).has("shots");
if (SHOTS) {
  // Screenshots for the website: ?player=0 hides the music player, clips get real-looking thumbnails.
  localStorage.setItem("jc.player.hidden", new URLSearchParams(location.search).get("player") === "0" ? "1" : "0");
  const ART = ["wilderness-bound", "chaos-cubed", "tiny-takeover", "mounts-of-mayhem", "copper-age"];
  sampleClips.forEach((c, i) => ((c as { thumb?: string }).thumb = `https://justiceclient.online/art/${ART[i % ART.length]}.jpg`));
  const base = sampleInstances[0];
  sampleInstances.push(
    { ...base, id: "pvp", name: "PvP 1.21.11", icon: "sword", template: "pvp", lastPlayed: Date.now() / 1000 - 600, playtimeSecs: 30100, recordingMode: false },
    { ...base, id: "smp", name: "Justice SMP", icon: "crown", template: "smp", lastPlayed: Date.now() / 1000 - 7200, playtimeSecs: 52000, recordingMode: false },
    { ...base, id: "v263", name: "Vanilla 26.3", icon: "trees", loader: "vanilla", mcVersion: "26.3", template: "", lastPlayed: Date.now() / 1000 - 250000, playtimeSecs: 3000, recordingMode: false },
    { ...base, id: "burger", name: "Burger Survival", icon: "burger", mcVersion: "26.2", template: "smp", lastPlayed: Date.now() / 1000 - 400000, playtimeSecs: 8000, recordingMode: false },
  );
}
const now = Date.now() / 1000;
const me = { uuid: "0494ec66d9504e5d93016701417cfb8b", name: "Maxern_", badges: ["team", "early"], created: now - 86400, lastSeen: now, online: true, presence: null,
  profile: { status: "Točím nové video 🎬", banner: "red", bio: "", stats: { playtimeSecs: 19 * 3600, instances: 7, clips: 12, friends: 4, pvp: { kills: 142, deaths: 61, bestCombo: 17, hits: 3400 } }, cape: "justice", achievements: ["first", "h10", "inst5", "clip1", "friend1"] } };
const pvpOf = (k: number) => ({ playtimeSecs: k * 900, instances: 3, clips: 2, friends: 3, pvp: { kills: k, deaths: Math.round(k * 0.7) + 3, bestCombo: 5 + (k % 13), hits: k * 20 } });
const friend = (uuid: string, name: string, online: boolean, presence: unknown, unread = 0) => ({ uuid, name, online, presence, unread, badges: [], created: now - 3600, lastSeen: now - 5400, profile: {} });
const friends = [
  friend("069a79f444e94726a5befca90e38aaf5", "Notch", true, { state: "playing", instance: "PvP 1.21.11", mc: "1.21.11", loader: "fabric", server: "justicesmp.online" }, 2),
  friend("853c80ef3c3749fdaa49938b674adae6", "jeb_", true, { state: "online" }),
  friend("61699b2ed3274a019f1e0ea8c3f06bc6", "Dinnerbone", false, null),
];
friends.forEach((f, i) => ((f as { profile: object }).profile = { stats: pvpOf([188, 97, 40][i] ?? 10), cape: ["gold", "", "void"][i] ?? "" }));
// ?offline=1 previews the offline-account sign-in on the Friends page.
const OFFLINE = new URLSearchParams(location.search).has("offline");
const party = { id: "p1", leader: me.uuid, members: [me, friends[0]], invited: [friends[1]], created: now - 60 };
const msgs = [
  { id: 1, from: friends[0].uuid, to: me.uuid, kind: "text", body: "ahoj, jdeš na Justice SMP?", meta: {}, created: now - 900, read: true },
  { id: 2, from: me.uuid, to: friends[0].uuid, kind: "text", body: "jj, dej mi 5 minut, dotáčím klip", meta: {}, created: now - 840, read: true },
  { id: 3, from: me.uuid, to: friends[0].uuid, kind: "world", body: "Svět hráče Maxern_", meta: { world: "x", mc: "1.21.11", loader: "fabric" }, created: now - 300, read: true },
  { id: 4, from: friends[0].uuid, to: me.uuid, kind: "pack", body: "PvP 1.21.11", meta: { name: "PvP 1.21.11", mc: "1.21.11", loader: "fabric", code: "x" }, created: now - 120, read: false },
  { id: 5, from: friends[0].uuid, to: me.uuid, kind: "text", body: "tady máš můj pack, má i voicechat 🔥", meta: {}, created: now - 110, read: false },
];

// Fake music app (Windows media controls): a small queue that advances in real time.
const D = "/packaging/design/img/";
const PLACES: Record<string, unknown> = {
  cinematic: { kind: "world", name: "My World", image: D + "shaders.webp" },
  pvp: { kind: "server", name: "mc.hypixel.net", image: D + "pvp2.webp" },
  smp: { kind: "server", name: "justicesmp.online", image: D + "vanilla.webp" },
  v263: { kind: "world", name: "Builds", image: D + "pvp.webp" },
  burger: { kind: "world", name: "New World", image: D + "nihher.webp" },
};
const musicQueue = [
  ["Blinding Lights", "The Weeknd", 200], ["Levitating", "Dua Lipa", 203], ["STAY", "The Kid LAROI, Justin Bieber", 141], ["Heat Waves", "Glass Animals", 238], ["As It Was", "Harry Styles", 167],
].map(([title, author, d], i) => ({ title, author, duration: `${Math.floor((d as number) / 60)}:${String((d as number) % 60).padStart(2, "0")}`, d: d as number, videoId: `v${i}`, thumbnails: [{ url: D + ["pvp2", "vanilla", "shaders", "nihher", "pvp"][i] + ".webp", width: 544, height: 544 }] }));
const musicS = { i: 0, pos: 78, playing: true, vol: 70, t: Date.now() };
const musicTick = () => {
  const now = Date.now();
  if (musicS.playing) musicS.pos += (now - musicS.t) / 1000;
  musicS.t = now;
  if (musicS.pos >= musicQueue[musicS.i].d) { musicS.i = (musicS.i + 1) % musicQueue.length; musicS.pos = 0; }
};

const handlers: Record<string, (a: any) => unknown> = {
  instance_last_place: (a) => PLACES[a.id] ?? null,
  version_art: () => {
    const M = "https://launchercontent.mojang.com/v2/images/";
    const H = "https://justiceclient.online/art/";
    return {
      "26.3": { name: "Wilderness Bound", image: M + "dappledcamp540x540.jpg", wide: M + "MinecraftWildernessBoundLauncher772x350.png", hd: H + "wilderness-bound.jpg" },
      "26.2": { name: "Chaos Cubed", image: M + "26.2540x540.jpg", wide: M + "summerdropaddon772x350.png", hd: H + "chaos-cubed.jpg" },
      "1.21.11": { name: "Mounts of Mayhem", image: M + "1.21.11540x540.jpg", wide: M + "MinecraftMountsofMayhemDungeonDescentLauncher772x350.png", hd: H + "mounts-of-mayhem.jpg" },
      "26.1.2": { name: "Tiny Takeover", image: M + "26.1540x540.jpg", wide: M + "TinyTakeoverMiniManiaLauncher772x350.png", hd: H + "tiny-takeover.jpg" },
      "1.21.10": { name: "The Copper Age", image: M + "1.21.9540x540.jpg", wide: M + "MinecraftFallDropCampaignKeyArtMinecraftLauncher772x350.png", hd: H + "copper-age.jpg" },
    };
  },
  media_state: () => {
    musicTick();
    const q = musicQueue[musicS.i];
    return { id: "msedgewebview2.exe", source: "Sonolith", title: q.title, artist: q.author, album: "", thumb: q.thumbnails[0].url, thumbKey: q.title, position: musicS.pos, duration: q.d, playing: musicS.playing, canNext: true, canPrev: true, canSeek: true,
      sessions: [{ id: "msedgewebview2.exe", source: "Sonolith", title: q.title, playing: musicS.playing }, { id: "308046B0AF4A39CB", source: "Firefox", title: "Rating the VIRAL Spicy Bowl", playing: false }] };
  },
  media_command: (a) => {
    musicTick();
    const c = a.command;
    if (c === "playPause") musicS.playing = !musicS.playing;
    else if (c === "next") { musicS.i = (musicS.i + 1) % musicQueue.length; musicS.pos = 0; }
    else if (c === "previous") { if (musicS.pos > 5) musicS.pos = 0; else { musicS.i = (musicS.i + musicQueue.length - 1) % musicQueue.length; musicS.pos = 0; } }
    else if (c === "seek") musicS.pos = a.value;
  },
  open_music_app: () => null,
  get_settings: () => settings,
  save_settings: (a) => Object.assign(settings, a.settings),
  system_info: () => ({ totalRamMb: 16384, recommendedRamMb: 6144, version: "0.2.1-dev", hasCfKey: true }),
  hardware_info: () => ({ cpu: "12th Gen Intel(R) Core(TM) i3-12100F", threads: 8, gpus: ["NVIDIA GeForce GTX 1660 SUPER"], totalRamMb: 16384 }),
  list_instances: () => sampleInstances,
  get_instance: (a) => sampleInstances.find((i) => i.id === a.id),
  game_versions: () => ["26.3", "26.2", "26.1.2", "26.1", "1.21.11", "1.21.10", "1.21.9", "1.21.8", "1.21.4", "1.21.1", "1.20.6", "1.20.4", "1.20.1", "1.19.4", "1.18.2", "1.16.5", "1.12.2", "1.8.9"].map((id) => ({ id, kind: "release", releaseTime: "" })),
  loader_versions: () => [{ version: "0.17.2", stable: true }, { version: "0.17.1", stable: true }],
  instance_path: () => "D:/JusticeClient/instances/x",
  list_accounts: () => [{ id: "a", kind: OFFLINE ? "offline" : "msa", username: OFFLINE ? "Pepa_CZ" : "Maxern_", uuid: "069a79f444e94726a5befca90e38aaf5", skinUrl: "", skinVariant: "CLASSIC", active: true }],
  running_games: () => [],
  list_servers: () => [
    { id: "s1", name: "Justice SMP", address: "justicesmp.online", instance: "smp", pinned: true },
    { id: "s2", name: "Ertenix", address: "ertenix.net", instance: "pvp", pinned: true },
    { id: "s3", name: "Hypixel", address: "mc.hypixel.net", instance: "pvp", pinned: false },
    { id: "s4", name: "Starý server", address: "old.example.cz", instance: "", pinned: false },
  ],
  ping_server: (a) => a.address.startsWith("old.") ? Promise.reject("offline") : a.address.includes("hypixel") ? { online: 41203, max: 200000, motd: "§aHypixel Network §c[1.8-1.21] §6§lSKYBLOCK §e§lUPDATE", version: "1.21", icon: null, pingMs: 98 } : ({ online: a.address.includes("30000") ? 12 : 57, max: a.address.includes("30000") ? 69 : 500, motd: "§c-=- JUSTICE SMP -=-", version: "1.21.11", icon: null, pingMs: 24 }),
  free_space: () => 48 * 1024 ** 3,
  list_content: () => [{ projectId: "AANobbMI", title: "Sodium" }],
  search_content: () => ({
    total: 6,
    hits: [
      ["AANobbMI", "Sodium", "jellysquid3", "Moderní renderer, výrazně víc FPS bez změny vzhledu.", 82e6, ["optimization"]],
      ["YL57xq9U", "Iris Shaders", "coderbot", "Shadery pro Fabric, funguje s OptiFine packy a Sodiem.", 51e6, ["decoration", "optimization"]],
      ["gvQqBUqZ", "Lithium", "jellysquid3", "Optimalizace herní logiky: AI, fyzika, chunky.", 40e6, ["optimization"]],
      ["uXXizFIs", "Distant Horizons", "James Seibel", "Obrovská dohlednost díky úrovním detailu.", 9e6, ["optimization"]],
      ["4cXLbBGw", "Flashback", "Moulberry", "Nahrávání a střih záznamů ze hry, cinematic kamera.", 3e6, ["utility"]],
      ["w7ThoJFB", "Zoomify", "isXander", "Plynulý zoom jako v OptiFine, se spoustou nastavení.", 12e6, ["utility"]],
    ].map(([id, title, author, description, downloads, categories]) => ({ id, slug: String(title).toLowerCase(), title, author, description, downloads, categories, iconUrl: null, url: "", source: "modrinth", updated: new Date(Date.now() - 86400e3 * 5).toISOString() })),
  }),
  clips_get_settings: () => clipsSettings,
  clips_set_settings: (a) => Object.assign(clipsSettings, a.s),
  clips_status: () => ({ state: "recording", error: null, bufferBytes: 90e6, bufferSecs: 58.4, ffmpeg: "C:\ffmpeg\ffmpeg.exe", hotkeyError: null, gameRunning: true }),
  clips_list: () => sampleClips,
  social_status: () => ({ signedIn: !OFFLINE, uuid: OFFLINE ? null : me.uuid }),
  social_login: () => Promise.reject("JUSTICE_NEEDS_PASSWORD"),
  social_login_password: () => ({ token: "t", uuid: me.uuid, name: "Pepa_CZ" }),
  pvp_stats: () => me.profile.stats.pvp,
  get_capes: () => [],
  party_warp_here: () => ({ sent: 1 }),
  social_get: (a) =>
    a.path === "/me" ? me : a.path === "/friends" ? { friends, incoming: [], outgoing: [] } : a.path.startsWith("/messages/") ? { messages: msgs } : a.path === "/party" ? { party, invites: [] } : {},
  social_put: () => me,
  clips_devices: () => ({ outputs: ["Sluchátka (TUF GAMING H1)"], inputs: ["Mikrofon (TUF GAMING H1)"], defaultOutput: "Sluchátka (TUF GAMING H1)", defaultInput: "Mikrofon (TUF GAMING H1)" }),
  clips_monitors: () => [{ index: 0, name: "", width: 1920, height: 1080, primary: true }, { index: 1, name: "", width: 1920, height: 1080, primary: false }],
  "plugin:updater|check": () => SHOTS ? null : ({ rid: 1, currentVersion: "0.2.0", version: "0.2.1", date: new Date().toISOString(), body: "- Rychlé připojení na Justice SMP a Ertenix", rawJson: {} }),
};

(window as any).__TAURI_INTERNALS__ = {
  metadata: { currentWindow: { label: "main" }, currentWebview: { windowLabel: "main", label: "main" } },
  transformCallback: () => Math.floor(Math.random() * 1e9),
  convertFileSrc: (p: string) => p,
  invoke: async (cmd: string, args: any) => {
    if (cmd.startsWith("plugin:event|")) return 1;
    const h = handlers[cmd];
    if (h) return h(args ?? {});
    console.debug("[devMock] unhandled", cmd, args);
    return null;
  },
};
(window as any).__TAURI_EVENT_PLUGIN_INTERNALS__ = { unregisterListener: () => {} };

export {};
