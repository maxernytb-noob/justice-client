import { useEffect, useRef, useState } from "react";
import { listen } from "@tauri-apps/api/event";
import { getCurrentWindow } from "@tauri-apps/api/window";
import { useStore, type Page } from "./store";
import { Icon, instanceIcon } from "./icons";
import { api, social } from "./api";
import { uiPrefs, type NavPage, type Shortcut } from "./ui";
import { t, tr } from "./i18n";
import { Avatar, CrashDialog, customIconSrc, Toasts, useAsync } from "./components/common";
import Home from "./pages/Home";
import Instances from "./pages/Instances";
import InstanceView from "./pages/InstanceView";
import Browse from "./pages/Browse";
import Recording from "./pages/Recording";
import ClipsPage from "./pages/Clips";
import Friends from "./pages/Friends";
import Servers from "./pages/Servers";
import SettingsPage from "./pages/Settings";
import Accounts from "./pages/Accounts";
import Onboarding from "./components/Onboarding";
import Splash from "./components/Splash";
import LaunchOverlay from "./components/LaunchOverlay";
import UpdatePill from "./components/UpdateDialog";
import { PartyPrompts } from "./components/Party";
import MusicPlayer, { MusicNavButton } from "./components/MusicPlayer";
import LogoButton, { secretSearch, useSecrets } from "./components/Secrets";

export const NAV: Record<NavPage, { icon: string; label: string }> = {
  home: { icon: "home", label: "Domů" },
  instances: { icon: "box", label: "Instance" },
  browse: { icon: "puzzle", label: "Mody" },
  recording: { icon: "video", label: "Natáčení" },
  servers: { icon: "server", label: "Servery" },
  friends: { icon: "users", label: "Přátelé" },
  clips: { icon: "clips", label: "Clips" },
};

/** Sidebar shortcut to an instance (opens it) or a saved server (joins it). */
function ShortcutButton({ sc }: { sc: Shortcut }) {
  const { instances, go, play } = useStore();
  const [servers] = useAsync(() => (sc.kind === "server" ? api.listServers() : Promise.resolve([])), [sc.kind]);
  if (sc.kind === "instance") {
    const inst = instances.find((i) => i.id === sc.id);
    if (!inst) return null;
    const src = customIconSrc(inst.icon);
    return (
      <button className="sc" onClick={() => go({ page: "instance", id: inst.id })} onDoubleClick={() => play(inst.id)}>
        {src ? <img src={src} alt="" /> : <Icon name={instanceIcon(inst.icon, inst.template)} size={20} />}
        <span className="tip">{inst.name} · {tr("dvojklik = hrát", "double-click = play")}</span>
      </button>
    );
  }
  const srv = servers?.find((s) => s.id === sc.id);
  if (!srv) return null;
  return (
    <button className="sc" onClick={() => srv.instance && play(srv.instance, srv.address)} title={srv.name}>
      <Icon name="server" size={19} />
      <span className="tip">{srv.name} · {tr("připojit", "join")}</span>
    </button>
  );
}

/** Ctrl+K search: an instance opens it, a friend opens Friends, anything else searches mods. */
function TopSearch() {
  const { instances, go } = useStore();
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key.toLowerCase() === "k") {
        e.preventDefault();
        ref.current?.focus();
      }
    };
    addEventListener("keydown", k);
    return () => removeEventListener("keydown", k);
  }, []);
  const submit = async (q: string) => {
    const s = q.trim().toLowerCase();
    if (!s) return;
    if (secretSearch(s)) {
      if (ref.current) ref.current.value = "";
      return;
    }
    const inst = instances.find((i) => i.name.toLowerCase().includes(s));
    if (inst) return go({ page: "instance", id: inst.id });
    const fr = await social.friends().catch(() => null);
    if (fr?.friends.some((f) => f.name.toLowerCase().includes(s))) return go({ page: "friends" });
    go({ page: "browse", q: q.trim() });
  };
  return (
    <label className="tb-search">
      <Icon name="search" size={16} />
      <input ref={ref} placeholder={tr("Hledat instance, mody, kamarády…", "Search instances, mods, friends…")} onKeyDown={(e) => e.key === "Enter" && submit(e.currentTarget.value)} />
      <kbd>Ctrl K</kbd>
    </label>
  );
}

function TitleBar() {
  const { activeAccount, go, settings } = useStore();
  const win = getCurrentWindow();
  const name = activeAccount ? activeAccount.username : tr("Přidat účet", "Add account");
  return (
    <div className="titlebar" data-tauri-drag-region>
      <TopSearch />
      <div className="drag" data-tauri-drag-region />
      {settings?.streamerMode && (
        <span className="badge red" title={tr("Streamer mód je zapnutý", "Streamer mode is on")}>
          <Icon name="eyeoff" size={12} /> STREAMER
        </span>
      )}
      <UpdatePill />
      <button className="account-btn" onClick={() => go({ page: "accounts" })}>
        {activeAccount ? <Avatar account={activeAccount} /> : <Icon name="user" size={16} />}
        <span className="small">{name}</span>
        <Icon name="down" size={14} />
      </button>
      <div className="winbtns">
        <button onClick={() => win.minimize()} aria-label={tr("Minimalizovat", "Minimize")}>
          <Icon name="minus" size={16} />
        </button>
        <button onClick={() => win.toggleMaximize()} aria-label={tr("Maximalizovat", "Maximize")}>
          <Icon name="square" size={13} />
        </button>
        <button className="close" onClick={() => win.close()} aria-label={tr("Zavřít", "Close")}>
          <Icon name="x" size={16} />
        </button>
      </div>
    </div>
  );
}

/** Counts chat messages that arrive while the Friends page isn't open, with a toast for each. */
function useSocialNotifications(onFriends: boolean) {
  const { toast } = useStore();
  const [unread, setUnread] = useState(0);
  const [me, setMe] = useState<string | null>(null);
  const onRef = useRef(onFriends);
  onRef.current = onFriends;
  useEffect(() => {
    if (onFriends) setUnread(0);
  }, [onFriends]);
  useEffect(() => {
    const t = setInterval(() => social.status().then((s) => setMe(s.uuid)).catch(() => {}), 5000);
    social.status().then((s) => setMe(s.uuid)).catch(() => {});
    return () => clearInterval(t);
  }, []);
  useEffect(() => {
    const un = listen<any>("social-event", (e) => {
      const ev = e.payload;
      if (ev.type === "message" && ev.message.from !== me && !onRef.current) {
        setUnread((n) => n + 1);
        const m = ev.message;
        const what = m.kind === "world" ? tr(`tě zve do světa „${m.body}“`, `invites you to the world “${m.body}”`) : m.kind === "clip" ? tr("poslal klip", "sent a clip") : m.kind === "pack" ? tr("poslal modpack", "sent a modpack") : m.kind === "invite" ? tr("tě zve do hry", "invites you to play") : `: ${String(m.body).slice(0, 80)}`;
        social.friends().then((f) => {
          const name = f.friends.find((x) => x.uuid === m.from)?.name ?? tr("Přítel", "Friend");
          toast(`${name} ${what}`, "info");
        }).catch(() => {});
      } else if (ev.type === "friend-request" && !onRef.current) {
        setUnread((n) => n + 1);
        toast(tr(`${ev.from?.name} ti poslal žádost o přátelství`, `${ev.from?.name} sent you a friend request`), "info");
      }
    });
    return () => {
      un.then((f) => f());
    };
  }, [me, toast]);
  return unread;
}

export default function App() {
  const { nav, go, settings, activeAccount } = useStore();
  useSecrets();
  const prefs = uiPrefs(settings?.ui);
  const [, force] = useState(0);
  useEffect(() => force((x) => x + 1), [settings?.language]);

  const current = nav.page === "instance" ? "instances" : nav.page === "accounts" ? "" : nav.page;
  const unread = useSocialNotifications(current === "friends");
  let page;
  switch (nav.page) {
    case "home": page = <Home />; break;
    case "instances": page = <Instances />; break;
    case "instance": page = <InstanceView key={nav.id} id={nav.id!} tab={nav.tab} />; break;
    case "browse": page = <Browse key={`${nav.id ?? "browse"}|${nav.q ?? ""}`} instanceId={nav.id} initialKind={nav.tab} initialQuery={nav.q} />; break;
    case "recording": page = <Recording />; break;
    case "clips": page = <ClipsPage />; break;
    case "friends": page = <Friends />; break;
    case "servers": page = <Servers />; break;
    case "settings": page = <SettingsPage />; break;
    case "accounts": page = <Accounts />; break;
  }

  return (
    <div className="shell">
      <nav className="sidebar">
        <LogoButton />
        {prefs.navOrder
          .filter((p) => !prefs.navHidden.includes(p) && p !== "clips")
          .map((p) => (
            <button key={p} className={`navbtn ${current === p ? "active" : ""}`} onClick={() => go({ page: p })}>
              <Icon name={NAV[p].icon} size={21} />
              {p === "friends" && unread > 0 && current !== "friends" && <span className="nav-badge">{unread > 9 ? "9+" : unread}</span>}
              <span className="tip">{t(NAV[p].label)}</span>
            </button>
          ))}
        {prefs.shortcuts.length > 0 && <div className="sc-sep" />}
        {prefs.shortcuts.map((sc) => (
          <ShortcutButton key={`${sc.kind}:${sc.id}`} sc={sc} />
        ))}
        <div className="spacer" />
        {!prefs.navHidden.includes("clips") && (
          <button className={`navbtn ${current === "clips" ? "active" : ""}`} onClick={() => go({ page: "clips" })}>
            <Icon name="clips" size={21} />
            <span className="tip">Clips</span>
          </button>
        )}
        <MusicNavButton />
        <button className={`navbtn ${current === "settings" ? "active" : ""}`} onClick={() => go({ page: "settings" })}>
          <Icon name="settings" size={21} />
          <span className="tip">{t("Nastavení")}</span>
        </button>
        <button className="me-btn" onClick={() => go({ page: "accounts" })} title={activeAccount?.username ?? tr("Přidat účet", "Add account")}>
          {activeAccount ? <Avatar account={activeAccount} /> : <Icon name="user" size={18} />}
        </button>
      </nav>
      <main className="main">
        <TitleBar />
        {page}
        <MusicPlayer />
        <PartyPrompts />
        <Toasts />
        <CrashDialog />
        <LaunchOverlay />
        {settings && !settings.onboarded && <Onboarding />}
      </main>
      <Splash />
    </div>
  );
}
