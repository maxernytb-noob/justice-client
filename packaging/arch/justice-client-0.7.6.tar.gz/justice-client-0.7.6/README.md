# Justice Client

Minecraft launcher pro natáčení: černo-červené UI, maximum FPS, Flashback a mody z Modrinthu i CurseForge.

## Co umí

- **Instance**: Vanilla, Fabric, Quilt, Forge a NeoForge, libovolná verze. Každá instance má vlastní RAM, Javu, rozlišení a složky.
- **Šablony**: Cinematic (Flashback, Iris, Distant Horizons, Freecam, Zoomify + FPS mody), Max FPS, PvP a Survival SMP.
- **Prohlížeč modů**: Modrinth a CurseForge. Sám vybere správnou verzi, doinstaluje závislosti a funguje i na resource packy a shadery.
- **Správa obsahu**: zapínání a vypínání modů, mazání, hromadné aktualizace (před nimi se udělá automatická záloha), přetažení .jar/.zip myší.
- **Profily modů**: přepínání sad modů, třeba „Natáčení“ a „Hraní“.
- **Recording Mode**: vypne houpání kamery, změnu FOV i zkreslení obrazu. Po vypnutí vrátí původní nastavení.
- **Knihovna** Flashback replayů, exportovaných videí a screenshotů ze všech instancí.
- **OBS**: po spuštění hry přepne scénu a začne nahrávat, po zavření hry nahrávání zastaví.
- **Streamer mód**, Discord status.
- **Účty**: Microsoft (device code) i offline, 3D náhled skinu, nahrání skinu, výběr cape.
- **Servery**: ping, počet hráčů, MOTD, ikona a Quick Join přímo na server.
- **Analyzátor pádů**: česky vysvětlí, proč hra spadla, a ukáže podezřelý mod.
- **Zálohy** světů a snapshoty instancí s obnovou.
- **Sdílení**: kód `JUSTICE1:…`, export zipu s configy a import .mrpack a CurseForge modpacků.
- Java (Temurin) se stahuje automaticky ve správné verzi. Hra běží s optimalizovanými G1GC flagy a vyšší prioritou.

## Vývoj

Potřebuješ Node.js 20+, Rust (stable, MSVC) a WebView2.

```bash
npm install
npm run tauri dev      # spustí launcher s hot reloadem
npm run tauri build    # vytvoří instalačku v src-tauri/target/release/bundle/nsis
```

Test bez UI (stáhne, spustí a zase zavře hru):

```bash
src-tauri/target/debug/justice-client.exe --selftest 1.21.4 fabric cinematic
```

## Konfigurace

- Nastavení: `%APPDATA%\JusticeClient\settings.json`
- Data (instance, Java, knihovny, zálohy): cesta `dataDir` v nastavení
- Microsoft přihlášení používá Azure app `1d78c41d-dee8-40da-8516-194ccd654143`. Funguje až po schválení Minecraft AppID review.
- CurseForge vyžaduje API klíč z console.curseforge.com (Nastavení → Integrace).
- Discord status vyžaduje Application ID z discord.com/developers (Nastavení → Integrace).
