# Justice Client pro Arch Linux

## Instalace

Zkopíruj celou tuhle složku (`PKGBUILD`, `justice-client-0.1.0.tar.gz`, `justice-client.desktop`) na počítač s Archem a v ní spusť:

```bash
makepkg -si
```

`makepkg` sám doinstaluje, co je potřeba (Rust, Node.js, WebKitGTK), sestaví launcher a nainstaluje ho. Poprvé to trvá 5–15 minut podle výkonu PC.

Pak najdeš **Justice Client** v menu aplikací, nebo ho spustíš příkazem `justice-client`.

## Kde jsou data

- nastavení: `~/.config/JusticeClient/settings.json`
- hra, instance, Java: `~/.local/share/JusticeClient`

Javu si launcher stáhne sám (Eclipse Temurin pro Linux), systémová Java není potřeba.

## Odinstalace

```bash
sudo pacman -R justice-client
```

## Když něco nejde

- **Prázdné / bílé okno** (hlavně NVIDIA + Wayland): launcher to řeší sám přes `WEBKIT_DISABLE_DMABUF_RENDERER=1`. Kdyby to nestačilo, zkus `GDK_BACKEND=x11 justice-client`.
- **Discord status**: funguje s normálním i Flatpak Discordem.
- **Hra nemá zvuk**: doinstaluj `libpulse` (`sudo pacman -S libpulse`).
